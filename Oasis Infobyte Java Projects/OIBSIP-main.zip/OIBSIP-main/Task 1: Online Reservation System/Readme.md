This project includes the neccessary fields which are required during online reservation system. This project runs on a particular database which can be accessed by any authorize person to get information and saves time and burden as well.

There are following modules:
1. Login Form
2. Reservation Form
3. Cancellation (Deletion Form)

Softwares/Technologies Used: Java 8, NetBeans 8.2 RC, Xampp Server v8.1.25
