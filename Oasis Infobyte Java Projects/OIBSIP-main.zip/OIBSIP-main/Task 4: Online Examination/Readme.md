This project has of the following capabilities:
1. Login 
2. Update Profile and Password
3. Selecting Answers and MCQs
4. Timer and auto submit
5. Closing session and logout

Softwares/Technologies Used: Netbeans IDE 8.2 RC and Java 8, Xampp Server v8.1.25
