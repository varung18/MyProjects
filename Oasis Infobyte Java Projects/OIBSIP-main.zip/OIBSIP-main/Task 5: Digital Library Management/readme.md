The main objective of this project is to provide a complete automated Library by digitizing its each and every functionality.
Starting from the book, keeping and issuing of books and query generation are done within this essential project. It is a 
desktop application, powered by a web server. In this Java Case, Xampp server is used, which is responsible for maintaining
every single detail of the library. It has very user friendly interface which can be operated by any non-technical person.

There are essentially 2 modules on this project, merged under a single package:

1. Admin Module: They will have complete control over the system. They have permissions to manage the records of both books and students. More than that they can issue and return the books, if in case for the users. Moreover, they will have a list of pending returns by the users.

2. Users Module: A subset of this module, will have 2 identical features that admin has: Issue and return. More than that, they will also have a feature to submit a query.

Softwares/Technologies Used: Netbeans IDE 8.2 RC and Java 8, Xampp Server v8.1.25
