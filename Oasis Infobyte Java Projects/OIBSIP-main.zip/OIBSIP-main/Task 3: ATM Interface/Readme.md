This project consists of different classes and is a console-based application. When this program is executed, the user is prompted to enter their user id and user pin. Once the parameters authenticates successfully, the ATM functionalities are unlocked, which allows to perform the following operations.
1. Transaction History
2. Withdraw
3. Deposit
4. Transfer
5. Quit

Softwares/Technologies Used: Visual Studio Code, Java 8
