<footer class="main-footer">
    <div class="pull-right hidden-xs">
    Developer: SVIT-Vasad
    </div>
    <strong>LibraLink</strong> 
  </footer>
